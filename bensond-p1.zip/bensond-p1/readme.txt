Just run make to create the server.

The client doesn't work because I couldn't get sending an image to
work and I ran out of time.

The server will attempt to send an image file but the response is
incorrect.

The server works with web browsers.